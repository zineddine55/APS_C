typedef struct _expr Expr;
typedef enum _tag Tag;
typedef enum _oprim Oprim;
enum _tag {ASTNum, ASTId, ASTPrim};
enum _oprim { AST_ADD, AST_SUB, AST_DIV, AST_MUL };
struct _expr {	Tag tag;
              	union { int num;
			char* id;
			struct {Oprim op;Expr *opand1;Expr *opand2;} binOp;
		} content;
	};

Expr* newASTNum(int n);
Expr* newASTId(char* x);
Expr* newASTPrim(Oprim op, Expr* e1, Expr* e2);

#define tagOf(r) r->tag
#define getNum(r) r->content.num
#define getId(r) r->content.id
#define getOp(r) r->content.binOp.op
#define getOpand1(r) r->content.binOp.opand1
#define getOpand2(r) r->content.binOp.opand2

