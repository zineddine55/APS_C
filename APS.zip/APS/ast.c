#include <stdlib.h>
#include <stdio.h>
#include "ast.h"

Expr* newASTNum(int v) {
	Expr* r = malloc(sizeof(*r));
	r->tag = ASTNum;
	r->content.num = v;
	return r;
}

Expr* newASTId(char* v) {
	Expr* r = malloc(sizeof(*r));
	r->tag = ASTId;
	r->content.id = v;
	return r;
}

Expr* newASTPrim(Oprim op, Expr* e1, Expr* e2) {
	Expr* r = malloc(sizeof(*r));r->tag = ASTPrim;
	r->content.binOp.op = op;
	r->content.binOp.opand1 = e1;
	r->content.binOp.opand2 = e2;
	return r;
}
