#include <stdio.h>
#include "ast.h"
void printOp(Oprim op) {
  switch(op) {case AST_ADD : printf("add"); break;
  case AST_SUB : printf("sub"); break;
  case AST_MUL : printf("mul"); break;
  case AST_DIV : printf("div"); break;
  }
}

void printNum(int n) {
  printf("%d",n);
}

void printId(char* x) {
  printf("\"%s\"",x);
}

void printExpr(Expr *e) {
  switch(tagOf(e)) {
    case ASTNum : printNum(getNum(e)); break;
    case ASTId : printId(getId(e)); break;
    case ASTPrim : {
      printOp(getOp(e));
      printf("(");
      printExpr(getOpand1(e));
      printf(",");
      printExpr(getOpand2(e));
      printf(")");
      break;
    }
  }
}
